/** Automatically generated file. DO NOT MODIFY */
package app.sand.throughputtest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}